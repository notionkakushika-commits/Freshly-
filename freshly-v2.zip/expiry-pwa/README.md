# Freshly — iPhone導入手順 (GitHub Pages版)

このフォルダ一式 (index.html, sw.js, manifest.webmanifest, icon-*.png) を HTTPS のサーバに置けば、iPhoneでホーム画面に追加して普通のアプリのように使えます。Apple Developer登録($99/年)も審査も不要です。

## いちばん簡単な公開方法: Netlify Drop (無料・登録不要可)

1. PC/Macで Safari か Chrome で <https://app.netlify.com/drop> を開く
2. このフォルダ (expiry-pwa) を**フォルダごと**ブラウザの点線エリアにドラッグ&ドロップ
3. 数秒で `https://xxxx-xxxx.netlify.app` のような URL が発行される (この URL がアプリのアドレス)
4. その URL をiPhoneのSafariで開く (AirDrop/メール/メモ経由で送るのが楽)

※ Netlify はアカウント未登録でも仮の公開URLが作れますが、後で消えないようにするには無料アカウント登録を推奨します。代替: Vercel、GitHub Pages、Cloudflare Pages でもOKです。

## iPhone でアプリ化 (ホーム画面追加)

1. Safariで上記URLを開く (※ Chromeアプリではなく Safari で開くこと)
2. 画面下の共有ボタン (□に↑のアイコン) をタップ
3. 「ホーム画面に追加」を選択
4. 名前は「Freshly」のままで「追加」

これでホーム画面にアイコンが追加され、タップするとアプリ風(全画面・Safariのアドレスバーなし)で起動します。

## 使い方

1. アイコンから起動 → 「表(商品)」枠をタップしてカメラ起動 → 商品の表面を撮影
2. 「裏(期限)」枠をタップして期限印字部分を撮影
3. 「裏写真からOCRで日付抽出」をタップ → 日付欄に自動入力 (初回はOCR辞書を約10MBダウンロード)
4. 商品名(任意)を入れて「登録する」
5. ダッシュボードに期限が近い順で並ぶ。各行の「消去」ボタンで削除

## 重要な注意点

- **カメラはHTTPSでないと起動しません**。Netlify等の公開URLからアクセスしてください。ローカルファイル(`file://`)では動作不完全です。
- **データはiPhone内のIndexedDBに保存**されます。同じURLで開いている限り保持されますが、Safariの履歴/サイトデータを全消去すると消えます。バックアップが必要なら右上「書出」でJSONをエクスポートしてメール等に保存してください (画像は容量都合で書出には含めていません。必要なら拡張可)。
- **OCR辞書(日本語+英語)は初回のみ自動ダウンロード**。約10MB。次回以降はオフラインでOCR可。
- OCRの精度は印字の鮮明さに依存します。読めない場合は手動で日付を直してください。

## ファイル構成

- `index.html` … アプリ本体
- `sw.js` … Service Worker (オフライン用キャッシュ)
- `manifest.webmanifest` … PWA設定 (アプリ名/アイコン)
- `icon-180.png` / `icon-192.png` / `icon-512.png` / `icon-maskable-512.png` / `favicon-32.png`

## 次に拡張するなら

- 期限間近のプッシュ通知 (iOS 16.4+のWeb Pushで対応可。サーバが必要)
- 画像のトリミングUI (OCR精度が大幅に向上)
- クラウドOCR / LLM Visionに差し替え (印字独自フォーマットや手書きに強くなる)
- 家族や複数端末で共有 (Firebase等のサーバストレージへ移行)
